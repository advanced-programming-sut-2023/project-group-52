package org.example.model.loginAndRegisterAsset.capchaField;

import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.paint.ImagePattern;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

import java.awt.*;

public class CapchField extends Rectangle {
    private static String[] allCodes = {"1181", "1381", "1491", "1722", "1959"};
    private String code;

    public CapchField() throws HeadlessException {
        super(100, 100, 300, 100);
        int index = (int) Math.floor(Math.random() * 5);
        code = allCodes[index];
        this.setFill(new ImagePattern(
                new Image(CapchField.class.getResource("/image/" + code + ".png").toExternalForm())));
    }
    public void changeCapcha(){
        int index = (int) Math.floor(Math.random() * 5);
        code = allCodes[index];
        this.setFill(new ImagePattern(
                new Image(CapchField.class.getResource("/image/" + code + ".png").toExternalForm())));
    }

    public String getCode() {
        return code;
    }
}
