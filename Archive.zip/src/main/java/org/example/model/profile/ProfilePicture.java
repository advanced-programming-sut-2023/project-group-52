package org.example.model.profile;

import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import org.example.model.loginAndRegisterAsset.capchaField.CapchField;

import java.awt.*;
import java.io.File;
import java.net.MalformedURLException;

public class ProfilePicture extends Rectangle {
    private int code;
    public ProfilePicture(int code) {

        super(100,100);
        this.code=code;
        this.setFill(new ImagePattern(
                new Image(CapchField.class.getResource("/image/avatar/" + code + ".png").toExternalForm())));
    }
    public ProfilePicture(String address){
        super(100,100);
        this.code=code;
        this.setFill(new ImagePattern(
                new Image(CapchField.class.getResource(address).toExternalForm())));
    }
    public void changePicture(int code){
        this.code=code;
        this.setFill(new ImagePattern(
                new Image(CapchField.class.getResource("/image/avatar/" + code + ".png").toExternalForm())));
    }
    public void changePicture(String address){
        this.code=code;
        this.setFill(new ImagePattern(
                new Image(CapchField.class.getResource(address).toExternalForm())));
    }
    public void changePicture(File file) throws MalformedURLException {

        this.code=code;
        this.setFill(new ImagePattern(
                new Image(file.getPath())));
    }

}
