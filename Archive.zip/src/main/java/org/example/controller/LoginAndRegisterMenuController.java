package org.example.controller;

import org.example.model.User;
import org.example.view.loginAndRegisterMenu.login.SecurityQuestionAsking;

import java.awt.*;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;

public class LoginAndRegisterMenuController {

    public static boolean isUserNameFormatCorrect(String userName) {
        userName=Controller.giveTrueString(userName);
        if (userName.matches("^.*[^A-Za-z\\_0-9].*$") ||
                userName.matches("^.* .*$")) {
            return false;
        }
        return true;
    }
    public static boolean isFieldEmpty(String fieldContext) {
        if (fieldContext.equals(null)) return true;
        else if (fieldContext.matches("^ *$")) return true;
        return false;
    }
    private static String creatNewUsernameBecauseOfRepetition(String username) {
        String result = username;
        int counter = 1;
        while (User.getUserByUsername(result) != null) {
            result = username + counter;
            counter += 1;
        }
        return result;
    }
    public static String registerUserName(String username) {
        String newUserName = "";
        username=Controller.giveTrueString(username);
        String result="";
        if (isFieldEmpty(username)) {
            result=("username field is empty");

        }
        if (!isUserNameFormatCorrect(username)) {
            result=("username format is invalid");

        }
        if (User.getUserByUsername(username) != null) {
            result=("already there is a user with this name");
            String answer = "no";
            int counter=0;
            newUserName = creatNewUsernameBecauseOfRepetition(username);
//            while (!answer.matches("^yes$")) {
//                System.out.println("do you like this name instead");
//                newUserName+=counter;
//                counter+=1;
//                System.out.println(newUserName);
//            }

        }
        return result;
    }
    public static boolean isPasswordStrongEnough(String password) {
        password=Controller.giveTrueString(password);
        if (password.length() < 6 ||
                !password.matches("^.*[a-z].*$") ||
                !password.matches("^.*[A-Z].*$") ||
                !password.matches("^.*\\d.*$") ||
                !password.matches("^.*[a-zA-Z0-9].*$") ||
                password.matches("^.* .*$")) {
            return false;
        }
        return true;
    }
    public static String registerPassword(String password) {

        String randomPassword="";

        int checkRandom=1;
        if (isFieldEmpty(password)) {
            return ("password field is empty");

        }
//        if (password.matches("random")){
//            checkRandom=0;
//            randomPassword=generateSecurePassword();
//            System.out.println("your random password is:"+randomPassword+"please enter this password");
//            String checkRandoomPassword= Menu.getScanner().nextLine();
//            if(!checkRandoomPassword.equals(randomPassword)) {
//                System.out.println("password incorrect! registeration failed!");
//                return false;
//            }
//        }
        if (!isPasswordStrongEnough(password) && checkRandom==1) {
            return ("password not strong enough");

        }
//        String passwordConfirmation=matcher.group("passwordConfirmation");
//        if(checkRandom==1 &&
//                isFieldEmpty(passwordConfirmation)){
//            return ("passwordConfirmation field is empty");
//
//        }
//        if (checkRandom==1 && !password.equals(passwordConfirmation)){
//            return ("password confirmation is wrong");
//
//        }
        return "";
    }
    public static String generateSecurePassword() {
        String password="";
        int min=2;
        int max=4;
        int numberOfBigLetters=(int)Math.floor(Math.random()*(max-min+1)+min);
        for(int i=0;i<numberOfBigLetters;i++){
            int minChar=65;
            int maxChar=90;
            int randomCharNumber=(int)Math.floor(Math.random()*(maxChar-minChar+1)+minChar);
            password+=(char)randomCharNumber;
        }
        int numberOfSmallLetters=(int)Math.floor(Math.random()*(max-min+1)+min);
        for(int i=0;i<numberOfSmallLetters;i++){
            int minChar=97;
            int maxChar=122;
            int randomCharNumber=(int)Math.floor(Math.random()*(maxChar-minChar+1)+minChar);
            password+=(char)randomCharNumber;
        }
        int numberOfSpecialLetters=(int)Math.floor(Math.random()*(max-min+1)+min);
        for(int i=0;i<numberOfSpecialLetters;i++){
            int minChar=33;
            int maxChar=46;
            int randomCharNumber=(int)Math.floor(Math.random()*(maxChar-minChar+1)+minChar);
            password+=(char)randomCharNumber;
        }
        int numberOfNumericLetters=(int)Math.floor(Math.random()*(max-min+1)+min);
        for(int i=0;i<numberOfSpecialLetters;i++){
            int minChar=0;
            int maxChar=9;
            int randomCharNumber=(int)Math.floor(Math.random()*(maxChar-minChar+1)+minChar);
            password+=randomCharNumber;
        }
        List<String> allLetters= Arrays.asList(password.split(""));
        Collections.shuffle(allLetters);
        password="";
        for (String string:allLetters){
            password+=string;
        }
        return password;
    }
    public static String registerNickname(String nickname){

        if(isFieldEmpty(nickname)) {
            return ("nickname field is empty");
        }
        return "";
    }
    public static String registerEmail(String email){
        if (isFieldEmpty(email)) {
            return ("email field is empty");

        }
        if (User.getUserByEmail(email)!=null){
            return ("a user with this email already exists");

        }
        if (!isEmailValidFormat(email)){
            return ("email format incorrect");
        }
        return "";
    }
    private static boolean isEmailValidFormat(String email) {
        return email.matches("^[a-zA-Z\\.\\_0-9]+@[a-zA-Z\\.\\_0-9]+\\.[a-zA-Z\\.\\_0-9]+$");
    }
    public static String registerSlogan(String slogan) {
        String newSlogan = "";
//        if (slogan.matches("random")) {
//            return ("your new slogan:" + newSlogan);
//        }
        if(isSloganFieldEmpty(slogan)){
            return "slogan field is empty!";
        }
        return "";
    }
    public static boolean isSloganFieldEmpty(String fieldContext) {
        if (fieldContext==null || fieldContext.matches("^ *$")) return true;
        return false;
    }
    public static String forgotPassword(String username,String answer){
        username=Controller.giveTrueString(username);
        if(User.getUserByUsername(username)==null){
            return ("user with this username does not exist");

        }
        User user=User.getUserByUsername(username);
        int idQuestion=user.getSecurityQuestionNumber();
//        System.out.println(SecurityQuestionAsking.allQuestions[idQuestion-1]);
//        if(!answer.equals(user.getSecurityQuestionAnswer())){
//            return ("wrong Answer");
//
//        }
        if(!user.isPasswordSameAsBefore(answer)){
            return "wrong password!";
        }
        return "";
//        System.out.println("new password?");
//        String newPassword=Menu.getScanner().nextLine();
//        while(!SignUpMenuController.isPasswordStrongEnough(newPassword)){
//            System.out.println("weak password try again!");
//            newPassword=Menu.getScanner().nextLine();
//        }
//        user.setPassword(newPassword);

    }


}
