package org.example.controller;

import org.example.model.User;

public class Controller {
    public static User currentUser;
    public static String giveTrueString(String username) {
        if(username.length()!=0) {
            if (username.charAt(0) == '"' && username.charAt(username.length() - 1) == '"')
                username = username.substring(1, username.length() - 1);
        }
        return username;
    }

    public static User getCurrentUser() {
        return currentUser;
    }
}
