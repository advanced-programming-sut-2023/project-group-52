package org.example.controller;

import org.example.model.User;

import java.util.regex.Matcher;

public class ProfileMenuController {
    public static String changeUsername(String username) {
        User currentUser = Controller.getCurrentUser();

        if (LoginAndRegisterMenuController.isFieldEmpty(username)) {
            return ("username field is empty");

        }
        if (!LoginAndRegisterMenuController.isUserNameFormatCorrect(username)) {
            return ("username format is invalid");

        }
        User user=User.getUserByUsername(username);
        if(user!=null) {
            if (user.equals(currentUser)) {
                return ("username is same");
            }
            if (!user.equals(currentUser) && User.getUserByUsername(username) != null) {
                return ("someone else has this username");

            }
        }
//        currentUser.setUsername(username);
        return "";

    }
    public static String changePassword(String password) {
        User currentUser = Controller.getCurrentUser();
        if (LoginAndRegisterMenuController.isFieldEmpty(password)) {
            return("Password field is empty");

        }
        else if(!LoginAndRegisterMenuController.isPasswordStrongEnough(password)){
            return "password not strong";
        }
//        String newPassword = matcher.group("newPassword");
//        if (LoginAndRegisterMenuController.isFieldEmpty(newPassword)) {
//            return("newPassword field is empty");
//
//        }
//        if (!currentUser.isPasswordSameAsBefore(password)) {
//            return ("password is wrong");
//
//        }
        if(currentUser!=null) {
            if (currentUser.isPasswordSameAsBefore(password)) {
                return ("new password is same as the old one");

            }
        }
        return "";


    }
    public static String changeNickname(String nickname) {
        User currentUser = Controller.getCurrentUser();

        if (LoginAndRegisterMenuController.isFieldEmpty(nickname)) {
            return("nickname field is empty");

        }
        if (!LoginAndRegisterMenuController.isUserNameFormatCorrect(nickname)) {
            return("nickname format is invalid");

        }
//        System.out.println("success");
//        currentUser.setNickname(nickname);
        return "";
    }
    private static boolean isEmailValidFormat(String email) {
        return email.matches("^[a-zA-Z\\.\\_0-9]+@[a-zA-Z\\.\\_0-9]+\\.[a-zA-Z\\.\\_0-9]+$");
    }
    public static String changeEmail(String email) {
        User currentUser = Controller.getCurrentUser();

        if (LoginAndRegisterMenuController.isFieldEmpty(email)) {
            return ("email field is empty");

        }
        if (!isEmailValidFormat(email)) {
            return ("email format is invalid");

        }
        User user = User.getUserByEmail(email);
        if (user != null) {
            if (user.equals(currentUser)) {
                return ("email is same");
            }
            if (!user.equals(currentUser) ) {
                return ("someone else has this username");

            }
        }return "";
    }

}
