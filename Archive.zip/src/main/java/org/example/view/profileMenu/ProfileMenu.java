package org.example.view.profileMenu;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.example.controller.Controller;
import org.example.controller.LoginAndRegisterMenuController;
import org.example.controller.ProfileMenuController;
import org.example.model.User;
import org.example.model.loginAndRegisterAsset.Slogan;
import org.example.model.loginAndRegisterAsset.peekablePasswordField.PeekablePasswordField;
import org.example.model.profile.ProfilePicture;
import org.example.view.loginAndRegisterMenu.login.LoginMenu;
import org.example.view.startMenu.StartMenu;

import javax.security.auth.callback.Callback;
import java.awt.*;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class ProfileMenu extends Application {
    TextField username;
    Label usernameLabel;
    Label passwordLabel;
    Label sloganLabel;
    Label emailLabel;
    Label nicknameLAbel;
    TextField nickname;
    PeekablePasswordField password;
    TextField email;
    TextField slogan;
    javafx.scene.control.Label usernameErrorLabel=new javafx.scene.control.Label();
    javafx.scene.control.Label passwordErrorLabel=new javafx.scene.control.Label();
    javafx.scene.control.Label nicknameErrorLabel=new javafx.scene.control.Label();
    javafx.scene.control.Label emailError=new javafx.scene.control.Label();
    javafx.scene.control.Label sloganError=new javafx.scene.control.Label();
    javafx.scene.control.Button randomSlogan;

    javafx.scene.control.Button register;
    ArrayList<Label> allErrorLabels=new ArrayList<>();
    LoginAndRegisterMenuController controller=new LoginAndRegisterMenuController();
    Scene scene;
    Stage stage;
    ChoiceBox sloganBox;
    ChoiceBox avatarBox;
    User user;
    public void start(Stage stage) throws Exception {
        this.stage=stage;
        //HHHHHHHHHHH
        user= Controller.currentUser;
        //HHHHHHHHHH
        String name = "/fxml/loginAndRegister/capcha.fxml";
        URL url = ProfileMenu.class.getResource(name);
        AnchorPane borderPane = FXMLLoader.load(url);
        VBox vBox=new VBox();
        startPane(vBox);
        borderPane.getChildren().add(vBox);
         scene = new Scene(borderPane);
        stage.setScene(scene);
        stage.show();
    }
    public void startPane(VBox vBox){
        addUsernameTextField(vBox);
        vBox.getChildren().add(new Label());
        addPasswordTextField(vBox);
        addSloganTextField(vBox);
        addNicknameTextField(vBox);

        addEmailTextField(vBox);
        addAvatar(vBox);
        addSccoreBoard(vBox);
        addExitBoard(vBox);
    }
    public void addUsernameTextField(VBox vBox){
        HBox hBox=new HBox();
        usernameLabel=new Label("username: "+user.getUsername());
        hBox.getChildren().add(usernameLabel);
        VBox vBox1=new VBox();
        username=new TextField();
        usernameErrorLabel.setText("username field is empty");
        username.textProperty().addListener(((observable, oldValue, newValue) -> {
            usernameErrorLabel.setText(ProfileMenuController.changeUsername(username.getText()));
            if(usernameErrorLabel.getText().length()!=0) username.setStyle("-fx-text-inner-color: red;");
            else username.setStyle("-fx-text-inner-color: black;");
        }));
        vBox1.getChildren().add(username);
        vBox1.getChildren().add(usernameErrorLabel);
        hBox.getChildren().add(vBox1);
        javafx.scene.control.Button submit=new Button("submit");
        submit.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if(usernameErrorLabel.getText().length()==0){
                    Alert alert=new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Success");
                    alert.setContentText("change username successful");
                    alert.showAndWait();
                    user.setUsername(username.getText());
                    usernameLabel.setText("username: "+user.getUsername());

                }
                else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Profile Error");
                    alert.setContentText(usernameErrorLabel.getText());
                    alert.showAndWait();
                }
            }
        });
        hBox.getChildren().add(submit);
        vBox.getChildren().add(hBox);
    }
    public void addPasswordTextField(VBox vBox){
        HBox hBox=new HBox();
        hBox.getChildren().add(new Label("password"));
        Button change=new Button("change");
        GridPane grid = new GridPane();

//        grid.setHgap(10);
//        grid.setVgap(10);
//        grid.setPadding(new Insets(0, 10, 0, 10));
//        final TextField username = new TextField();
//        username.setPromptText("Username");
//        final PasswordField password = new PasswordField();
//        password.setPromptText("Password");
//
//        grid.add(new Label("Username:"), 0, 0);
//        grid.add(username, 1, 0);
//        grid.add(new Label("Password:"), 0, 1);
//        grid.add(password, 1, 1);
//
//        String usernameResult;
//        String passwordResult;
//
//        Callback myCallback = new Callback() {
//            @Override
//            public Void call(Void param) {
//                usernameResult = username.getText();
//                passwordResult = password.getText();
//                return null;
//            }
//        };
//
//        DialogResponse resp = Dialogs.showCustomDialog(stage, grid, "Please log in", "Login", DialogOptions.OK_CANCEL, myCallback);
//        System.out.println("Custom Dialog: User clicked: " + resp);
////You must check the resp, since input fields' texts are returned regardless of what button was pressed. (ie. If user clicked 'Cancel' disregard the input)
//        System.out.println("Custom Dialog: Fields set from custom dialog: " + usernameResult + "/" + passwordResult);
//        hBox.getChildren().add(change);
//        TilePane r = new TilePane();
//        TextInputDialog td = new TextInputDialog("enter any text");
//        td.setContentText("oldPassword");
//        TextInputDialog td2 = new TextInputDialog("enter any text");
//        td2.setContentText("newPassword");
//        change.setOnAction(new EventHandler<ActionEvent>() {
//            @Override
//            public void handle(ActionEvent event) {
//                td.show();
//                td2.show();
//            }
//        });
//        r.getChildren().add(change);
//        hBox.getChildren().add(r);

//        Scene sc = new Scene(r, 500, 300);
//        stage.setScene(sc);
//
//        stage.show();

        passwordLabel=new Label("password: "+user.getPassword());
        hBox.getChildren().add(passwordLabel);
        VBox vBox1=new VBox();
        password=new PeekablePasswordField();
        passwordErrorLabel.setText("password field is empty");
        password.textProperty().addListener(((observable, oldValue, newValue) -> {
            passwordErrorLabel.setText(ProfileMenuController.changePassword(password.getText()));
            if(passwordErrorLabel.getText().length()!=0) password.setStyle("-fx-text-inner-color: red;");
            else password.setStyle("-fx-text-inner-color: black;");
        }));
        vBox1.getChildren().add(password);
        vBox1.getChildren().add(passwordErrorLabel);
        hBox.getChildren().add(vBox1);
        javafx.scene.control.Button submit=new Button("submit");
        submit.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if(passwordErrorLabel.getText().length()==0){
                    Alert alert=new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Success");
                    alert.setContentText("change password successful");
                    alert.showAndWait();
                    user.setPassword(password.getText());
                    passwordLabel.setText("password: "+user.getPassword());

                }
                else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Profile Error");
                    alert.setContentText(passwordErrorLabel.getText());
                    alert.showAndWait();
                }
            }
        });
        hBox.getChildren().add(submit);
        vBox.getChildren().add(hBox);
    }
    public void addSloganTextField(VBox vBox){
        HBox hBox=new HBox();
//        sloganLabel=new Label("slogan: "+user.getSlogan());
//        hBox.getChildren().add(sloganLabel);
        VBox vBox1=new VBox();
        slogan=new TextField();
        hBox.getChildren().add(slogan);
        ArrayList<String> allSlogans=new ArrayList<>();
        String[] allPervSlogans= Slogan.getAllSloagns();
        for(String sl:allPervSlogans){
            if(!allSlogans.contains(sl)) allSlogans.add(sl);
        }
        for(User user1:User.getAllUsers()){
            if(!allSlogans.contains(user1.getSlogan())) allSlogans.add(user1.getSlogan());
        }
        String[] allSlo=new String[allSlogans.size()];
        for(int i=0;i<allSlogans.size();i++){
            allSlo[i]=allSlogans.get(i);
        }
        sloganBox=new ChoiceBox(FXCollections.observableArrayList(allSlo));
        sloganBox.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {

            // if the item of the list is changed
            public void changed(ObservableValue ov, Number value, Number new_value)
            {
                // set the text for the label to the selected item
//                chosenQuestion.setText(allQuestions[new_value.intValue()]);
//                user.setSecurityQuestionNumber(sloganBox);
                slogan.setText(allSlo[new_value.intValue()]);
            }
        });
        vBox1.getChildren().add(sloganBox);
//        vBox1.getChildren().add(username);
//        vBox1.getChildren().add(usernameErrorLabel);
        hBox.getChildren().add(vBox1);
        javafx.scene.control.Button submit=new Button("submit");
        submit.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
//                if(sloganLabel.getText().length()==0){
                    Alert alert=new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Success");
                    alert.setContentText("change username successful");
                    alert.showAndWait();
                    if(slogan.getText().length()==0){
                        slogan.setText("is slogan");
                    }
                    user.setSlogan(sloganLabel.getText());
//                    usernameLabel.setText("username: "+user.getUsername());

//                }
//                else {
//                    Alert alert = new Alert(Alert.AlertType.ERROR);
//                    alert.setTitle("Error");
//                    alert.setHeaderText("Profile Error");
//                    alert.setContentText(usernameErrorLabel.getText());
//                    alert.showAndWait();
//                }
            }
        });
        hBox.getChildren().add(submit);
        vBox.getChildren().add(hBox);
    }

    public void setUser(User user) {
        this.user = user;
    }
    public void addNicknameTextField(VBox vBox){
        HBox hBox=new HBox();
        nicknameLAbel=new Label("nickname: "+user.getNickname());
        hBox.getChildren().add(nicknameLAbel);
        VBox vBox1=new VBox();
        nickname=new TextField();
        nicknameErrorLabel.setText("nickname field is empty");
        nickname.textProperty().addListener(((observable, oldValue, newValue) -> {
            nicknameErrorLabel.setText(ProfileMenuController.changeNickname(nickname.getText()));
            if(nicknameErrorLabel.getText().length()!=0) nickname.setStyle("-fx-text-inner-color: red;");
            else nickname.setStyle("-fx-text-inner-color: black;");
        }));
        vBox1.getChildren().add(nickname);
        vBox1.getChildren().add(nicknameErrorLabel);
        hBox.getChildren().add(vBox1);
        javafx.scene.control.Button submit=new Button("submit");
        submit.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if(nicknameErrorLabel.getText().length()==0){
                    Alert alert=new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Success");
                    alert.setContentText("change nickname successful");
                    alert.showAndWait();
                    user.setNickname(username.getText());
                    nicknameLAbel.setText("nickname: "+user.getUsername());

                }
                else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Profile Error");
                    alert.setContentText(nicknameErrorLabel.getText());
                    alert.showAndWait();
                }
            }
        });
        hBox.getChildren().add(submit);
        vBox.getChildren().add(hBox);
    }
    public void addEmailTextField(VBox vBox){
        HBox hBox=new HBox();
        emailLabel=new Label("email: "+user.getEmail());
        hBox.getChildren().add(emailLabel);
        VBox vBox1=new VBox();
        email=new TextField();
        emailError.setText("email field is empty");
        email.textProperty().addListener(((observable, oldValue, newValue) -> {
            emailError.setText(ProfileMenuController.changeEmail(email.getText()));
            if(emailError.getText().length()!=0) email.setStyle("-fx-text-inner-color: red;");
            else email.setStyle("-fx-text-inner-color: black;");
        }));
        vBox1.getChildren().add(email);
        vBox1.getChildren().add(emailError);
        hBox.getChildren().add(vBox1);
        javafx.scene.control.Button submit=new Button("submit");
        submit.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if(emailError.getText().length()==0){
                    Alert alert=new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Success");
                    alert.setContentText("change nickname successful");
                    alert.showAndWait();
                    user.setNickname(username.getText());
                    emailLabel.setText("nickname: "+user.getUsername());

                }
                else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Profile Error");
                    alert.setContentText(nicknameErrorLabel.getText());
                    alert.showAndWait();
                }
            }
        });
        hBox.getChildren().add(submit);
        vBox.getChildren().add(hBox);
    }
    public void addAvatar(VBox vBox){
        HBox hBox=new HBox();
        ProfilePicture profilePicture=new ProfilePicture(user.getAvatarImageNumber());
        hBox.getChildren().add(profilePicture);
        Button change=new Button("change from file");
        change.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                FileChooser file_chooser = new FileChooser();
//                File file = file_chooser.showOpenDialog(StartMenu.stage);
                                File file = file_chooser.showOpenDialog(new Stage());
                if (file != null) {
                    try {
                        profilePicture.changePicture(file);
                    } catch (MalformedURLException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        });
        ArrayList<ProfilePicture> allAvatars=new ArrayList<>();
        for(int i=1;i<4;i++){
             allAvatars.add(new ProfilePicture(i));
        }
//        for(User user1:User.getAllUsers()){
//            allAvatars.add(new ProfilePicture(user1.pictureAddress));
//        }
       ProfilePicture[] allPic=new ProfilePicture[allAvatars.size()];
        for(int i=0;i<allAvatars.size();i++){
            allPic[i]=allAvatars.get(i);
        }
        hBox.getChildren().add(change);
        vBox.getChildren().add(hBox);
        avatarBox=new ChoiceBox(FXCollections.observableArrayList(allPic));
        avatarBox.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {

            // if the item of the list is changed
            public void changed(ObservableValue ov, Number value, Number new_value)
            {
                // set the text for the label to the selected item
//                chosenQuestion.setText(allQuestions[new_value.intValue()]);
                user.profilePicture=allPic[new_value.intValue()];
            }
        });
        hBox.getChildren().add(avatarBox);

    }
    public void addSccoreBoard(VBox vBox){
        Button scoreBoard=new Button("scoreboard");
        scoreBoard.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    new ScoreBoardMenu(0).start(StartMenu.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
        vBox.getChildren().add(scoreBoard);
    }
    public void addExitBoard(VBox vBox){
        Button exit=new Button("exit");
        exit.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    new StartMenu().start(StartMenu.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
        vBox.getChildren().add(exit);
    }

}
