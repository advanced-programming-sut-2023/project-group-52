package org.example.view.profileMenu;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.controller.Controller;
import org.example.model.User;
import org.example.view.startMenu.StartMenu;

import java.net.URL;

public class ScoreBoardMenu extends Application {
    User user;
    int counter=1;

    public ScoreBoardMenu(int counter) {
        this.counter=counter;
    }

    public void start(Stage stage) throws Exception {

        //HHHHHHHHHHH
        user= Controller.currentUser;
        //HHHHHHHHHH

        String name = "/fxml/loginAndRegister/capcha.fxml";
        URL url = ProfileMenu.class.getResource(name);
        AnchorPane borderPane = FXMLLoader.load(url);
        VBox vBox=new VBox();
        beginPane(vBox);
        borderPane.getChildren().add(vBox);
        Scene scene = new Scene(borderPane);
        stage.setScene(scene);
        stage.show();
    }
    public void beginPane(VBox vBox){
        addRank(vBox);
        addScoreboard(vBox);

    }
    public void addRank(VBox vBox){
        HBox hBox=new HBox();
        Button up=new Button("up");
        up.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if(counter>9) {
                    try {
                        new ScoreBoardMenu(counter-10).start(StartMenu.stage);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        });
        Button down=new Button("down");
        down.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if(counter+10<User.getScoreBoard().size()) {
                    try {
                        new ScoreBoardMenu(counter+10).start(StartMenu.stage);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        });
        hBox.getChildren().add(new Label(user.getUsername()+":  "+user.getRank()));
        hBox.getChildren().add(up);
        hBox.getChildren().add(down);
        vBox.getChildren().add(hBox);

    }
    public void addScoreboard(VBox vBox){
        vBox.getChildren().add(new Label());
        vBox.getChildren().add(new Label());
        vBox.getChildren().add(new Label());
        int i=counter;
        while (i<(counter+10) && i<User.getScoreBoard().size()){
            User scorer=User.getScoreBoard().get(i);
            vBox.getChildren().add(new Label(scorer.getUsername()+":  "+user.getRank()));
            i++;
        }
    }
}
