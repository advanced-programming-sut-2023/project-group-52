package org.example.view.loginAndRegisterMenu.register;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.controller.Controller;
import org.example.controller.LoginAndRegisterMenuController;
import org.example.model.User;
import org.example.model.loginAndRegisterAsset.capchaField.CapchField;
import org.example.model.loginAndRegisterAsset.peekablePasswordField.PeekablePasswordField;
import org.example.view.loginAndRegisterMenu.login.LoginMenu;
import javafx.scene.control.*;
import java.awt.*;

import javafx.scene.control.*;
import org.example.view.loginAndRegisterMenu.login.SecurityQuestionAsking;
import org.example.view.profileMenu.ProfileMenu;
import org.example.view.startMenu.StartMenu;

import java.net.URL;
import java.util.Optional;


public class RegisterMenu extends Application {
    Button button=new Button();
    private javafx.scene.control.TextField usernameField=new javafx.scene.control.TextField();

    private PeekablePasswordField passwordField=new PeekablePasswordField();
    public RegisterMenu() {
    }

    public void start(Stage stage) throws Exception {
        String name = "/fxml/loginAndRegister/registerMenu.fxml";
        URL url = LoginMenu.class.getResource(name);
        VBox vBox=new VBox();
        BorderPane borderPane = FXMLLoader.load(url);
        beginPane(vBox);
        borderPane.getChildren().add(vBox);

        Scene scene = new Scene(borderPane);
        stage.setScene(scene);
        stage.show();
    }
    public void beginPane(VBox vBox){
        vBox.getChildren().add(usernameField);
        usernameField.setMinWidth(100);
        vBox.getChildren().add(passwordField);
        passwordField.setMinWidth(100);
        Button submit=new Button("submit");
        vBox.getChildren().add(submit);
        submit.setMinWidth(100);
        HBox capchaHbox=new HBox();
        CapchField capchField=new CapchField();
        TextField answerCapcha=new TextField();
        javafx.scene.control.Button changeCapcha=new javafx.scene.control.Button("change capcha");
        changeCapcha.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                capchField.changeCapcha();
            }

        });
        capchaHbox.getChildren().add(capchField);
        VBox vBox1=new VBox();
        vBox1.getChildren().add(changeCapcha);
        vBox1.getChildren().add(answerCapcha);
        changeCapcha.setMinWidth(150);
        answerCapcha.setMinWidth(150);
        capchaHbox.getChildren().add(vBox1);
        vBox.getChildren().add(capchaHbox);
        submit.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                boolean check=true;
                User user=User.getUserByUsername(usernameField.getText());
                if(LoginAndRegisterMenuController.forgotPassword(usernameField.getText(),passwordField.getText()).length()!=0){
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Register Error");
                    alert.setContentText(LoginAndRegisterMenuController.forgotPassword(usernameField.getText(),passwordField.getText()));
                    alert.showAndWait();
                    capchField.changeCapcha();

                }
                else if(!answerCapcha.getText().equals(capchField.getCode())){
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Register Error");
                    alert.setContentText("capcha wrong");
                    alert.showAndWait();
                    capchField.changeCapcha() ;
                }
                else {
                    Alert alert=new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Success");
                    alert.setContentText("register successful");
                    alert.showAndWait();
                    Controller.currentUser=user;
                    try {
                        new ProfileMenu().start(StartMenu.stage);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }

                }
//                if(user==null){
//                    Alert alert = new Alert(Alert.AlertType.ERROR);
//                    alert.setTitle("Error");
//                    alert.setHeaderText("Register Error");
//                    alert.setContentText("no user with this name exists!");
//                    alert.showAndWait();
//                }
//                else if (!user.isPasswordSameAsBefore(passwordField.getText())){
//                    Alert alert = new Alert(Alert.AlertType.ERROR);
//                    alert.setTitle("Error");
//                    alert.setHeaderText("Register Error");
//                    alert.setContentText("wrong password!");
//                    alert.showAndWait();
//                }
            }
        });
        Button forgot=new Button("forgot");
        vBox.getChildren().add(forgot);
        forgot.setMinWidth(100);
        Button submitForgot=new Button("submitForgot");
        submitForgot.setMinWidth(100);
        javafx.scene.control.Label forgotAnswerLabel=new Label();
        forgotAnswerLabel.setMinWidth(200);
        TextField forgotAnswer=new TextField();
        forgotAnswer.setMinWidth(100);
        forgot.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                User user=User.getUserByUsername(usernameField.getText());
                if(user==null){
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Register Error");
                    alert.setContentText("no user");
                    alert.showAndWait();
                }
                else {
                    HBox hBox = new HBox();
                    vBox.getChildren().remove(forgot);
                    forgotAnswerLabel.setText(SecurityQuestionAsking.allQuestions[user.getSecurityQuestionNumber()]);
                    hBox.getChildren().add(forgotAnswerLabel);
                    hBox.getChildren().add(forgotAnswer);
                    hBox.getChildren().add(submitForgot);
                    vBox.getChildren().add(hBox);
                }
            }
        });
        submitForgot.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                User user=User.getUserByUsername(usernameField.getText());
                if(!forgotAnswer.getText().equals(user.getSecurityQuestionAnswer())){
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Register Error");
                    alert.setContentText("wrong answer");
                    alert.showAndWait();

                }

                else if(!answerCapcha.getText().equals(capchField.getCode())){
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Register Error");
                    alert.setContentText("capcha wrong");
                    alert.showAndWait();
                    capchField.changeCapcha() ;
                }
                else {
                    Alert alert=new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Success");
                    alert.setContentText("register successful");
                    alert.showAndWait();
                    Controller.currentUser=user;
                    try {
                        new ProfileMenu().start(StartMenu.stage);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }

            }
        });

//
//        hBox.getChildren().add(answer);
//        javafx.scene.control.Button submit=new javafx.scene.control.Button("submit");
//        submit.setOnAction(new EventHandler<ActionEvent>() {
//            @Override
//            public void handle(ActionEvent event) {
//                if(answer.getText().equals(capchField.getCode())){
//                    Alert alert=new Alert(Alert.AlertType.INFORMATION);
//                    alert.setTitle("Success");
//                    alert.setContentText("capcha successful");
//                    alert.showAndWait();
//                    try {
//                        new StartMenu().start(StartMenu.stage);
//                    } catch (Exception e) {
//                        throw new RuntimeException(e);
//                    }
//                }
//                else {
//                    Alert alert = new Alert(Alert.AlertType.ERROR);
//                    alert.setTitle("Error");
//                    alert.setHeaderText("Register Error");
//                    alert.setContentText("wrong capcha!");
//                    alert.showAndWait();
//                    capchField.changeCapcha();
////                    answer.setText("");
//
//                }
//            }
//
//        });

//        username.textProperty().addListener(((observable, oldValue, newValue) -> {
//            usernameErrorLabel.setText(LoginAndRegisterMenuController.registerUserName(username.getText()));
//            if(usernameErrorLabel.getText().length()!=0) username.setStyle("-fx-text-inner-color: red;");
//            else username.setStyle("-fx-text-inner-color: black;");
//        }));
    }
}
