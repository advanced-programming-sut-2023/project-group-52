package org.example.view.loginAndRegisterMenu.login;

public class LoginMenuController {
}
