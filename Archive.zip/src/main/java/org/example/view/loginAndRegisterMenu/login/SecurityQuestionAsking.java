package org.example.view.loginAndRegisterMenu.login;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.model.User;
import org.example.view.startMenu.StartMenu;

import java.net.URL;

public class SecurityQuestionAsking extends Application {
    User user;
    public ChoiceBox questionBox;
    public Label chosenQuestion=new Label();
    public TextField answer;
    public static String[] allQuestions={"1. What is my father’s name",
            "2.What was my first pet’s name?","3. What is my mother’s last name?"};

    public SecurityQuestionAsking() {
    }

    public void start(Stage stage) throws Exception {
        String name = "/fxml/loginAndRegister/securityQuestion.fxml";
        URL url = LoginMenu.class.getResource(name);
        AnchorPane borderPane = FXMLLoader.load(url);
        VBox vBox=new VBox();
        beginPane(vBox);
        borderPane.getChildren().add(vBox);
        Scene scene = new Scene(borderPane);
        stage.setScene(scene);
        stage.show();
    }
    public void beginPane(VBox vBox) throws Exception {
        addQuestion(vBox);
        addAnswer(vBox);
        addSubmit(vBox);

    }
    public void addAnswer(VBox vBox){
        answer=new TextField();
        vBox.getChildren().add(answer);
    }
    public void addSubmit(VBox vBox) throws Exception {
        Button submit=new Button("submit");
        submit.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                user.setSecurityQuestionAnswer(answer.getText());
                try {
                    new Capcha().start(StartMenu.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
        vBox.getChildren().add(submit);

    }
    public void addQuestion(VBox vBox){
        HBox hBox=new HBox();

        questionBox=new ChoiceBox(FXCollections.observableArrayList(allQuestions));
        user.setSecurityQuestionNumber(1);
        questionBox.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {

            // if the item of the list is changed
            public void changed(ObservableValue ov, Number value, Number new_value)
            {
                // set the text for the label to the selected item
//                chosenQuestion.setText(allQuestions[new_value.intValue()]);
                user.setSecurityQuestionNumber(new_value.intValue());
            }
        });
//        hBox.getChildren().add(chosenQuestion);
        hBox.getChildren().add(questionBox);
        vBox.getChildren().add(hBox);
    }

    public void setUser(User user) {
        this.user = user;
    }
}
