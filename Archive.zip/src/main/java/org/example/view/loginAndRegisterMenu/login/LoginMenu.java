package org.example.view.loginAndRegisterMenu.login;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import org.example.controller.LoginAndRegisterMenuController;
import org.example.model.User;
import org.example.model.loginAndRegisterAsset.Slogan;
import org.example.model.loginAndRegisterAsset.peekablePasswordField.PeekablePasswordField;
import org.example.view.startMenu.StartMenu;

import java.net.URL;
import java.util.ArrayList;

public class LoginMenu extends Application {
    TextField username;
    TextField nickname;
    PeekablePasswordField password;
    TextField email;
    TextField slogan;
    Label usernameErrorLabel=new Label();
    Label passwordErrorLabel=new Label();
    Label nicknameErrorLabel=new Label();
    Label emailError=new Label();
    Label sloganError=new Label();
    Button randomSlogan;

    Button register;
    ArrayList<Label> allErrorLabels=new ArrayList<>();
    LoginAndRegisterMenuController controller=new LoginAndRegisterMenuController();
    public LoginMenu() {
    }
    public void start(Stage stage) throws Exception {
        String name = "/fxml/loginAndRegister/loginMenu.fxml";
        URL url = LoginMenu.class.getResource(name);
        AnchorPane borderPane = FXMLLoader.load(url);
//        borderPane.getChildren().add(new TextField("KKKKK"));
        addAllLabels();
        beginPane(borderPane);
        System.out.println(borderPane.getChildren().size());
        Scene scene = new Scene(borderPane);
        stage.setScene(scene);
        stage.show();
    }
    public void addAllLabels(){
        allErrorLabels.add(usernameErrorLabel);
        allErrorLabels.add(passwordErrorLabel);
        allErrorLabels.add(nicknameErrorLabel);
        allErrorLabels.add(emailError);
        allErrorLabels.add(sloganError);
    }
    public void beginPane(Pane pane){
        TextField textField=new TextField();
        VBox vBox=new VBox();
        vBox.getChildren().add(addUsernameTextField());
        vBox.getChildren().add(addPasswordTextField());
        vBox.getChildren().add(addNickNameField());
        vBox.getChildren().add(addEmailField());
        vBox.getChildren().add(addSlogan());
        vBox.getChildren().add(addRegisterButton());
        vBox.getChildren().add(backButton());
        pane.getChildren().add(vBox);
    }
    public HBox addUsernameTextField(){
        HBox hBox=new HBox();
        username=new TextField();
        usernameErrorLabel.setText("username field is empty");
        username.textProperty().addListener(((observable, oldValue, newValue) -> {
            usernameErrorLabel.setText(LoginAndRegisterMenuController.registerUserName(username.getText()));
            if(usernameErrorLabel.getText().length()!=0) username.setStyle("-fx-text-inner-color: red;");
            else username.setStyle("-fx-text-inner-color: black;");
        }));
        hBox.getChildren().add(username);
        hBox.getChildren().add(usernameErrorLabel);
        return hBox;
    }
    public HBox addPasswordTextField(){
        HBox hBox=new HBox();
        password=new PeekablePasswordField();
        passwordErrorLabel.setText("password is empty");
        Button randomButton=new Button("random");
        Label newPassword=new Label();
        Button okButton=okButton=new Button("ok");
//        hBox.getChildren().remove(okButton);
        hBox.getChildren().add(okButton);
        okButton.setOnAction(event1 -> {
            password.setText(newPassword.getText());
//            hBox.getChildren().remove(okButton);
            hBox.getChildren().remove(newPassword);
        });
        randomButton.setOnAction(event -> {

            newPassword.setText(LoginAndRegisterMenuController.generateSecurePassword());
            hBox.getChildren().remove(newPassword);
            hBox.getChildren().add(newPassword);


        });
        password.textProperty().addListener(((observable, oldValue, newValue) -> {
            passwordErrorLabel.setText(LoginAndRegisterMenuController.registerPassword(password.getText()));
            if(passwordErrorLabel.getText().length()!=0) password.setStyle("-fx-text-inner-color: red;");
            else password.setStyle("-fx-text-inner-color: black;");
        }));
        hBox.getChildren().add(password);
        hBox.getChildren().add(passwordErrorLabel);
        hBox.getChildren().add(randomButton);
        return hBox;
    }
    public HBox addNickNameField(){
        HBox hBox=new HBox();
        nickname=new TextField();
        nicknameErrorLabel.setText("nickname field is empty");
        nickname.textProperty().addListener(((observable, oldValue, newValue) -> {
            nicknameErrorLabel.setText(LoginAndRegisterMenuController.registerNickname(nickname.getText()));
            if(nicknameErrorLabel.getText().length()!=0) nickname.setStyle("-fx-text-inner-color: red;");
            else nickname.setStyle("-fx-text-inner-color: black;");
        }));
        hBox.getChildren().add(nickname);
        hBox.getChildren().add(nicknameErrorLabel);
        return hBox;
    }
    public HBox addEmailField(){
        HBox hBox=new HBox();
        email=new TextField();
        emailError.setText("email field is empty");
        email.textProperty().addListener(((observable, oldValue, newValue) -> {
            emailError.setText(LoginAndRegisterMenuController.registerEmail(email.getText()));
            if(emailError.getText().length()!=0) email.setStyle("-fx-text-inner-color: red;");
            else email.setStyle("-fx-text-inner-color: black;");
        }));
        hBox.getChildren().add(email);
        hBox.getChildren().add(emailError);
        return hBox;
    }
    public HBox addSlogan(){
        HBox hBox=new HBox();
        slogan=new TextField();
        sloganError.setText("");
        CheckBox c = new CheckBox("slogan?");
        hBox.getChildren().add(c);
        randomSlogan=new Button("random");
        String[] allSlogans=Slogan.getAllSloagns();
        ChoiceBox sloganCheckBox=new ChoiceBox(FXCollections.observableArrayList(allSlogans));
        sloganCheckBox.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {

            // if the item of the list is changed
            public void changed(ObservableValue ov, Number value, Number new_value)
            {
                // set the text for the label to the selected item
                slogan.setText(allSlogans[new_value.intValue()]);
            }
        });
        EventHandler<ActionEvent> event=new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if(c.isSelected()){
                   sloganError.setText("slogan Field is empty!");
                   hBox.getChildren().add(slogan);
                   hBox.getChildren().add(sloganError);
                   hBox.getChildren().add(randomSlogan);
                   hBox.getChildren().add(sloganCheckBox);

                }
                else {
                    sloganError.setText("");
                    hBox.getChildren().remove(slogan);
                    hBox.getChildren().remove(sloganError);
                    hBox.getChildren().remove(randomSlogan);
                    hBox.getChildren().remove(sloganCheckBox);
                }
            }
        };
        EventHandler<ActionEvent > chooseRandomSlogan=new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                int rand=(int)Math.floor(Math.random()*(3)+1);
                slogan.setText(Slogan.getContentById(rand));
            }
        };
        randomSlogan.setOnAction(chooseRandomSlogan);

        c.setOnAction(event);
        slogan.textProperty().addListener(((observable, oldValue, newValue) -> {
            sloganError.setText(LoginAndRegisterMenuController.registerSlogan(slogan.getText()));
            if(sloganError.getText().length()!=0) slogan.setStyle("-fx-text-inner-color: red;");
            else slogan.setStyle("-fx-text-inner-color: black;");
        }));
        return hBox;
    }
    public Button addRegisterButton(){
        register=new Button("register");
        register.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                boolean noError=true;
                System.out.println(allErrorLabels.size());
                for(Label label:allErrorLabels){
                    if(label.getText().length()!=0){
                        noError=false;
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Error");
                        alert.setHeaderText("Register Error");
                        alert.setContentText(label.getText());
                        alert.showAndWait();
                        break;
                    }
                }
                if(noError){
                    Alert alert=new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Success");
                    alert.setContentText("register successful");
                    alert.showAndWait();
                    User user=new User(username.getText(),password.getText(),nickname.getText(),slogan.getText(),email.getText());
                    SecurityQuestionAsking page=new SecurityQuestionAsking();
                    page.setUser(user);
                    try {
                        page.start(StartMenu.stage);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }

                }
            }
        });
        return register;
    }
    public Button backButton(){
        Button exit=new Button("exit");
        exit.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    new StartMenu().start(StartMenu.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
        return exit;
    }

}
