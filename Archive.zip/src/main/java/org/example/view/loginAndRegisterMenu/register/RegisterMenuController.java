package org.example.view.loginAndRegisterMenu.register;

public class RegisterMenuController {
}
