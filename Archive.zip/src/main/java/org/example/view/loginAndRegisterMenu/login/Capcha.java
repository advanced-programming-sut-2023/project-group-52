package org.example.view.loginAndRegisterMenu.login;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.model.User;
import org.example.model.loginAndRegisterAsset.capchaField.CapchField;
import org.example.view.startMenu.StartMenu;
import javafx.scene.control.*;

import java.awt.*;
import java.net.URL;

public class Capcha extends Application {
    CapchField capchField;
    javafx.scene.control.TextField answer= new javafx.scene.control.TextField();
    public void start(Stage stage) throws Exception {
        String name = "/fxml/loginAndRegister/capcha.fxml";
        URL url = LoginMenu.class.getResource(name);
        AnchorPane borderPane = FXMLLoader.load(url);
        VBox vBox=new VBox();
        beginPane(vBox);
        borderPane.getChildren().add(vBox);
        Scene scene = new Scene(borderPane);
        stage.setScene(scene);
        stage.show();
    }
    public void beginPane(VBox vBox){
        addCapcha(vBox);
        addAnswer(vBox);
    }
    public void addCapcha(VBox vBox){
        capchField=new CapchField();
        capchField.setX(400);
        capchField.setY(400);
        vBox.getChildren().add(capchField);
    }
    public void addText(VBox vBox){
        javafx.scene.control.TextField answer2=new javafx.scene.control.TextField();
        vBox.getChildren().add(answer2);
    }


    public void addAnswer(VBox vBox){
        HBox hBox=new HBox();

        hBox.getChildren().add(answer);
        javafx.scene.control.Button submit=new javafx.scene.control.Button("submit");
        submit.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if(answer.getText().equals(capchField.getCode())){
                    Alert alert=new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Success");
                    alert.setContentText("capcha successful");
                    alert.showAndWait();
                    try {
                        new StartMenu().start(StartMenu.stage);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
                else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Register Error");
                    alert.setContentText("wrong capcha!");
                    alert.showAndWait();
                    capchField.changeCapcha();
//                    answer.setText("");

                }
            }

        });
        javafx.scene.control.Button change=new javafx.scene.control.Button("change");
        change.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                capchField.changeCapcha();
            }

        });
        hBox.getChildren().add(submit);
        hBox.getChildren().add(change);
        vBox.getChildren().add(hBox);
    }
}
