package org.example.view.startMenu;

import javafx.scene.input.MouseEvent;
import org.example.view.loginAndRegisterMenu.login.LoginMenu;
import org.example.view.loginAndRegisterMenu.register.RegisterMenu;

public class StartMenuController {
    public void login(MouseEvent mouseEvent) throws Exception {
        new LoginMenu().start(StartMenu.stage);
    }

    public void register(MouseEvent mouseEvent) throws Exception {
        new RegisterMenu().start(StartMenu.stage);
    }
}
