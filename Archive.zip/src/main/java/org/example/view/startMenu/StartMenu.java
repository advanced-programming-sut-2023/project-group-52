package org.example.view.startMenu;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.net.URL;

public class StartMenu extends Application {
    public static Stage stage;

    public StartMenu() {
    }

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {

        StartMenu.stage = stage;
        stage.show();
        String name = "/fxml/start.fxml";
        URL url = StartMenu.class.getResource(name);
        BorderPane borderPane = FXMLLoader.load(url);
//        addPictures(borderPane);
        Scene scene = new Scene(borderPane);
        stage.setScene(scene);
        stage.show();
    }
}
